package edu.buffalo.cse.sql.plan;

public class ArrayList {
	
}
